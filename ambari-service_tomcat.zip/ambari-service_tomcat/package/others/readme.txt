server.xml，tomcat目录下/conf/server.xml的demo，用以理解修改端口改动的地方。
change_port.sh，在ambari平台修改tomcat端口的脚本。
jdk_install.sh，安装jdk并配置环境变量。